import fitz  # PyMuPDF

def extract_text_from_pdf(pdf_bytes):
    """Extract selectable text from a PDF held in memory."""
    document = fitz.open(stream=pdf_bytes, filetype="pdf")
    try:
        return "\n".join(page.get_text("text") for page in document)
    finally:
        document.close()
