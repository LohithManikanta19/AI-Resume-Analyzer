import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

SKILLS = [
    "python", "java", "javascript", "typescript", "c++", "c#", "sql",
    "html", "css", "react", "node.js", "flask", "django", "fastapi",
    "machine learning", "deep learning", "natural language processing",
    "nlp", "pandas", "numpy", "scikit-learn", "tensorflow", "pytorch",
    "data analysis", "power bi", "tableau", "excel", "aws", "azure",
    "docker", "kubernetes", "git", "github", "mongodb", "mysql",
    "postgresql", "linux", "rest api", "communication", "leadership"
]

def extract_skills(text):
    normalized = text.lower()
    found = []
    for skill in SKILLS:
        # Match whole terms while allowing punctuation in skills such as C++.
        pattern = r"(?<![a-z0-9])" + re.escape(skill) + r"(?![a-z0-9])"
        if re.search(pattern, normalized):
            found.append(skill)
    return sorted(set(found))

def analyze_resume(resume_text, job_description):
    resume_skills = extract_skills(resume_text)
    job_skills = extract_skills(job_description)

    matched = sorted(set(resume_skills) & set(job_skills))
    missing = sorted(set(job_skills) - set(resume_skills))

    try:
        matrix = TfidfVectorizer(stop_words="english").fit_transform(
            [resume_text, job_description]
        )
        text_similarity = float(cosine_similarity(matrix[0:1], matrix[1:2])[0][0])
    except ValueError:
        text_similarity = 0.0

    if job_skills:
        skill_match = len(matched) / len(job_skills)
        score = round((0.65 * skill_match + 0.35 * text_similarity) * 100)
    else:
        score = round(text_similarity * 100)

    suggestions = []
    if missing:
        suggestions.append("If you genuinely have these skills, add relevant examples to your resume: " + ", ".join(missing[:8]) + ".")
    if not re.search(r"\b(project|projects)\b", resume_text, re.I):
        suggestions.append("Consider adding a Projects section with the problem, tools used, and measurable outcome.")
    if not re.search(r"\b(education|university|college|degree)\b", resume_text, re.I):
        suggestions.append("Make sure your education or relevant training is clearly listed.")
    if not suggestions:
        suggestions.append("Your resume includes several relevant terms. Improve it further with specific achievements and measurable results.")

    return {
        "score": max(0, min(100, score)),
        "resume_skills": resume_skills,
        "job_skills": job_skills,
        "matched_skills": matched,
        "missing_skills": missing,
        "suggestions": suggestions,
        "text_similarity": round(text_similarity * 100, 1),
    }
