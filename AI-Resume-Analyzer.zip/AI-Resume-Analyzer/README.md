# AI Resume Analyzer & Job Matcher

A beginner-friendly Flask web app that extracts text from a PDF resume, compares it with a job description, identifies matching and missing skills, and provides an indicative match score.

## Features
- PDF resume text extraction with PyMuPDF
- Skill identification using a starter keyword list
- Job/resume text similarity using TF-IDF and cosine similarity
- Matched skills and missing skills report
- Basic resume improvement suggestions
- Responsive web interface
- Upload is processed in memory; the PDF is not saved to disk

## Tech stack
Python, Flask, PyMuPDF, scikit-learn, HTML, CSS.

## Run locally

1. Install Python 3.10 or newer.
2. Clone or download this repository.
3. Open a terminal in the project folder.
4. Create and activate a virtual environment:

   **Windows**
   ```bash
   py -m venv .venv
   .venv\Scripts\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

5. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
6. Start the app:
   ```bash
   python app.py
   ```
7. Open http://127.0.0.1:5000 in your browser.

## Push to GitHub

Create an empty repository on GitHub, then run:

```bash
git init
git add .
git commit -m "Build AI Resume Analyzer and Job Matcher"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/AI-Resume-Analyzer.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## Important limitations
- This is an educational ATS-style analyzer, not an official ATS system or a hiring decision tool.
- The score combines skill overlap and TF-IDF text similarity. It is not a validated hiring prediction.
- The skill list is intentionally small and should be expanded for your target roles.
- Scanned/image-only PDFs need OCR before text can be extracted.
- Do not upload sensitive personal resumes to a public demo without consent and appropriate privacy protections.

## Future improvements
- Add OCR support for scanned PDFs.
- Expand skill taxonomy and recognize synonyms.
- Add user accounts and saved reports.
- Add explainable section-by-section feedback.
- Add optional LLM-powered suggestions with clear privacy controls.
