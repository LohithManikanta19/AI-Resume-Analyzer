from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
from utils.resume_parser import extract_text_from_pdf
from utils.resume_matcher import analyze_resume

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB
ALLOWED_EXTENSIONS = {"pdf"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    error = None

    if request.method == "POST":
        uploaded_file = request.files.get("resume")
        job_description = request.form.get("job_description", "").strip()

        if not uploaded_file or uploaded_file.filename == "":
            error = "Please choose a PDF resume."
        elif not allowed_file(uploaded_file.filename):
            error = "Only PDF files are supported."
        elif not job_description:
            error = "Please paste the job description."
        else:
            try:
                filename = secure_filename(uploaded_file.filename)
                resume_text = extract_text_from_pdf(uploaded_file.read())
                if len(resume_text.strip()) < 40:
                    error = "Could not extract enough text. If your PDF is scanned, run OCR on it first."
                else:
                    result = analyze_resume(resume_text, job_description)
                    result["filename"] = filename
            except Exception as exc:
                error = f"Could not read this PDF. Please try another file. ({type(exc).__name__})"

    return render_template("index.html", result=result, error=error)

@app.errorhandler(413)
def too_large(_error):
    return render_template("index.html", error="File is too large. Maximum upload size is 5 MB.", result=None), 413

if __name__ == "__main__":
    app.run(debug=True)
